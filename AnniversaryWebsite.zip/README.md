# 6 Months Anniversary 💖

A simple romantic interactive webpage to celebrate 6 beautiful months of love together.

Click the envelope, read the letter, blow the candle, cut the cake, and dance to our favorite song – "Tenekoi".

Made with love 💌.
